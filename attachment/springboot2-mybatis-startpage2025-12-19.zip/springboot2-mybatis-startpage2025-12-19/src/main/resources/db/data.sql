INSERT INTO tbl_demo (id, area_code, phone, reference)
VALUES(1, 'ac1', '1351', 'ref1');

INSERT INTO tbl_demo (id, area_code, phone, reference)
VALUES(2, 'ac2', '1352', 'ref2');

INSERT INTO tbl_demo (id, area_code, phone, reference)
VALUES(3, 'ac3', '1353', 'ref3');

INSERT INTO tbl_demo (id, area_code, phone, reference)
VALUES(4, 'ac4', '1354', 'ref4');

INSERT INTO tbl_demo (id, area_code, phone, reference)
VALUES(5, 'ac5', '1355', 'ref5');
