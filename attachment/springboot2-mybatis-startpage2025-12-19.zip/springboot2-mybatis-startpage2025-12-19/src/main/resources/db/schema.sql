drop table tbl_demo if exists;
create table if not exists tbl_demo (
    id int not null primary key auto_increment,
    area_code varchar(32),
    phone varchar(32),
    reference varchar(32)
);