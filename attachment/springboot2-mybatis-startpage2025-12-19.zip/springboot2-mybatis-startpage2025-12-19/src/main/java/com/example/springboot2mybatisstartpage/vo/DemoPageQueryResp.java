package com.example.springboot2mybatisstartpage.vo;

import java.io.Serializable;

import lombok.Data;

@Data
public class DemoPageQueryResp implements Serializable {
    private Long id;
    private String areaCode;
    private String phone;
    private String reference;
}
