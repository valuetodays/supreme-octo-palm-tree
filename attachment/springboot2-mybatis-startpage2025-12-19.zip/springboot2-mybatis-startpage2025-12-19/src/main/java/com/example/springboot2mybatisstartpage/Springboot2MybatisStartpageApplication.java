package com.example.springboot2mybatisstartpage;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Springboot2MybatisStartpageApplication {

    public static void main(String[] args) {
        SpringApplication.run(Springboot2MybatisStartpageApplication.class, args);
    }

}
