package com.example.springboot2mybatisstartpage.common;

import java.io.Serializable;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@Data
public abstract class BasePageQueryParam implements Serializable {
    @ApiModelProperty(value = "页码，从1开始")
    private int pageNum = 1;
    @ApiModelProperty(value = "每页条数，默认是10")
    private int pageSize = 10;
}
