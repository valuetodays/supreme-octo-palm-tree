package com.example.springboot2mybatisstartpage.vo;

import java.io.Serializable;

import lombok.Data;

@Data
public class DemoPageQueryVo implements Serializable {
    private Long id;
}
