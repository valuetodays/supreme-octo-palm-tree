package com.example.springboot2mybatisstartpage;

import java.util.List;

import com.example.springboot2mybatisstartpage.vo.DemoPageQueryReq;
import com.example.springboot2mybatisstartpage.vo.DemoPageQueryResp;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface DemoMapper {

    List<DemoPageQueryResp> selectByAreaCode(DemoPageQueryReq req);

}
