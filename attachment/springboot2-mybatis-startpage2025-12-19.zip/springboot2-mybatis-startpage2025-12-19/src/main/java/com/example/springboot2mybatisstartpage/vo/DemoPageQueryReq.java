package com.example.springboot2mybatisstartpage.vo;

import com.example.springboot2mybatisstartpage.common.BasePageQueryParam;
import lombok.Data;
import lombok.EqualsAndHashCode;

@EqualsAndHashCode(callSuper = true)
@Data
public class DemoPageQueryReq extends BasePageQueryParam {
    private String areaCode;

}
