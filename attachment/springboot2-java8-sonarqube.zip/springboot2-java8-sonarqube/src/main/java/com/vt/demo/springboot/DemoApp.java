package com.vt.demo.springboot;

import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestControllerAdvice;

/**
 * @author lei.liu
 * @since 2019-05-22 10:51
 */
@SpringBootApplication
public class DemoApp {
    public static void main(String[] args) {
        SpringApplication.run(DemoApp.class, args);
    }


    @RestControllerAdvice
    @Slf4j
    public static class GlobalExceptionHandler {

        @ExceptionHandler(value = Exception.class)
        @ResponseBody
        public Rest jsonErrorHandler(Exception e) {
            log.error("!!!!!! " + e.getMessage(), e);
            return new Rest(500, e.getMessage());
        }

    }
}
