package com.vt.demo.springboot;

import lombok.Data;

@Data
public class AMessClass {
    private String message;
    private String user_name;
    private Integer AGE;
}
