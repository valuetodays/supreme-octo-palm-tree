package cn.valuetodays.sample.entity.po;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;

/**
 * .
 *
 * @author valuetodays
 * @since 2026-09-01
 */
@Data
@ApiModel("图书")
@TableName(value = "t_book", autoResultMap = true)
public class BookPO implements Serializable {
    private static final long serialVersionUID = 1L;
    @TableId(value = "id", type = IdType.AUTO)
    private Long id;
    @ApiModelProperty("类型ID")
    private Long typeId;
    @ApiModelProperty("图书isbn")
    private String bookIsbn;
    @ApiModelProperty("图书名称")
    private String bookName;
    @ApiModelProperty("状态")
    private StatusEnum status;

}
