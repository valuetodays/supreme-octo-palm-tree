package cn.valuetodays.sample.config;

import cn.valuetodays.sample.BizSqlInjector;
import com.baomidou.mybatisplus.core.injector.ISqlInjector;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * .
 *
 * @author valuetodays
 * @since 2026-09-01
 */
@Configuration
public class BeanConfig {

    @Bean
    public ISqlInjector sqlInjector() {
        return new BizSqlInjector();
    }

}
