package cn.valuetodays.sample.mapper;

import cn.valuetodays.sample.base.BizBaseMapper;
import cn.valuetodays.sample.entity.po.BookPO;

/**
 * .
 *
 * @author valuetodays
 * @since 2026-09-01
 */
public interface BookBizMapper extends BizBaseMapper<BookPO> {
}
