package cn.valuetodays.sample;

import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * .
 *
 * @author valuetodays
 * @since 2026-09-01
 */
@SpringBootApplication
@MapperScan(basePackages = {"cn.valuetodays.sample.**.mapper"})
public class App {
    public static void main(String[] args) {
        SpringApplication.run(App.class, args);
    }
}

