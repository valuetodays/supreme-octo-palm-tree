package cn.valuetodays.sample;

import java.util.List;
import java.util.stream.Collectors;

import cn.valuetodays.sample.base.BizBaseMapper;
import com.baomidou.mybatisplus.core.injector.AbstractMethod;
import com.baomidou.mybatisplus.core.injector.DefaultSqlInjector;
import com.baomidou.mybatisplus.core.injector.methods.Insert;
import com.baomidou.mybatisplus.core.injector.methods.UpdateById;
import com.baomidou.mybatisplus.core.metadata.TableInfo;

public class BizSqlInjector extends DefaultSqlInjector {

    @Override
    public List<AbstractMethod> getMethodList(
            Class<?> mapperClass,
            TableInfo tableInfo) {

        List<AbstractMethod> methodList = super.getMethodList(mapperClass, tableInfo);

        if (!BizBaseMapper.class.isAssignableFrom(mapperClass)) {
            return methodList;
        }

        return methodList.stream()
            .filter(method -> !(method instanceof Insert))
            .filter(method -> !(method instanceof UpdateById))
            .collect(Collectors.toList());
    }
}
