package cn.valuetodays.sample.mapper;

import cn.valuetodays.sample.entity.po.BookPO;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * .
 *
 * @author valuetodays
 * @since 2026-09-01
 */
public interface BookMapper extends BaseMapper<BookPO> {
}
