package cn.valuetodays.sample.entity.po;

/**
 * .
 *
 * @author valuetodays
 * @since 2026-09-01
 */
public enum StatusEnum {
    PENDING,
    PUBLISHED,
}
