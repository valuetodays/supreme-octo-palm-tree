INSERT INTO t_book (id, type_id, book_isbn, book_name, status)
VALUES(1, 100, 'aaa', 'java入门', 'PENDING'),
      (2, 101, 'bbb', 'java中级', 'PENDING'),
      (3, 102, 'ccc', 'java高级', 'PENDING');

