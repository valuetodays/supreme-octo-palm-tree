drop table t_book if exists;
create table if not exists t_book (
    id bigint not null primary key auto_increment,
    type_id bigint,
    book_isbn varchar(32),
    book_name varchar(32),
    status enum('PENDING', 'PUBLISHED')
);

