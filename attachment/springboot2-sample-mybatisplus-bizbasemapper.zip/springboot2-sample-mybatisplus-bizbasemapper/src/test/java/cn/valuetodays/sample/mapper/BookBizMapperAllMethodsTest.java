package cn.valuetodays.sample.mapper;

import cn.valuetodays.sample.AppTestBase;
import cn.valuetodays.sample.base.BizBaseMapper;
import cn.valuetodays.sample.entity.po.BookPO;
import cn.valuetodays.sample.entity.po.StatusEnum;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.conditions.update.UpdateWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import org.apache.ibatis.session.ResultContext;
import org.apache.ibatis.session.ResultHandler;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.transaction.annotation.Transactional;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * BizBaseMapper 全量方法验证。
 * 每个测试均在事务中执行并自动回滚，避免 delete/update 相互污染。
 */
@ActiveProfiles("test")
@Transactional
public class BookBizMapperAllMethodsTest extends AppTestBase {

    @Autowired
    private BookBizMapper mapper;

    @Test
    public void shouldNotExposeInsertAndUpdateById() {
        List<Method> methods = Arrays.asList(BizBaseMapper.class.getMethods());
        List<String> forbidden = methods.stream()
            .filter(m -> "insert".equals(m.getName()) || "updateById".equals(m.getName()) || "insertOrUpdate".equals(m.getName()))
            .map(Method::toGenericString)
            .collect(Collectors.toList());

        Assertions.assertTrue(forbidden.isEmpty(), "BizBaseMapper 不应暴露 insert/updateById/insertOrUpdate: " + forbidden);
    }

    @Test
    public void deleteByIdSerializable() {
        Assertions.assertEquals(1, mapper.deleteById(1L));
        Assertions.assertNull(mapper.selectById(1L));
    }

    @Test
    public void deleteByIdObjectWithUseFill() {
        Assertions.assertEquals(1, mapper.deleteById(1L, false));
        Assertions.assertNull(mapper.selectById(1L));
    }

    @Test
    public void deleteByIdEntity() {
        BookPO entity = new BookPO();
        entity.setId(1L);
        Assertions.assertEquals(1, mapper.deleteById(entity));
        Assertions.assertNull(mapper.selectById(1L));
    }

    @Test
    public void deleteByMap() {
        Map<String, Object> conditions = new HashMap<>();
        conditions.put("book_isbn", "aaa");
        Assertions.assertEquals(1, mapper.deleteByMap(conditions));
        Assertions.assertNull(mapper.selectById(1L));
    }

    @Test
    public void deleteByWrapper() {
        QueryWrapper<BookPO> qw = new QueryWrapper<>();
        qw.lambda().eq(BookPO::getTypeId, 100L);
        Assertions.assertEquals(1, mapper.delete(qw));
        Assertions.assertNull(mapper.selectById(1L));
    }

    @SuppressWarnings("deprecation")
    @Test
    public void deleteBatchIds() {
        Assertions.assertEquals(2, mapper.deleteBatchIds(Arrays.asList(1L, 2L)));
        Assertions.assertEquals(1L, mapper.selectCount(null));
    }

    @Test
    public void deleteByIds() {
        Assertions.assertEquals(2, mapper.deleteByIds(Arrays.asList(1L, 2L)));
        Assertions.assertEquals(1L, mapper.selectCount(null));
    }

    @Test
    public void deleteByIdsWithUseFill() {
        Assertions.assertEquals(2, mapper.deleteByIds(Arrays.asList(1L, 2L), false));
        Assertions.assertEquals(1L, mapper.selectCount(null));
    }

    @Test
    public void deleteByIdsEmptyCollection() {
        Assertions.assertEquals(0, mapper.deleteByIds(Collections.emptyList(), false));
        Assertions.assertEquals(3L, mapper.selectCount(null));
    }

    @Test
    public void updateEntityAndWrapper() {
        BookPO entity = new BookPO();
        entity.setStatus(StatusEnum.PUBLISHED);
        UpdateWrapper<BookPO> uw = new UpdateWrapper<>();
        uw.lambda().eq(BookPO::getId, 1L).eq(BookPO::getStatus, StatusEnum.PENDING);

        Assertions.assertEquals(1, mapper.update(entity, uw));
        Assertions.assertEquals(StatusEnum.PUBLISHED, mapper.selectById(1L).getStatus());
    }

    @Test
    public void updateWrapperOnly() {
        UpdateWrapper<BookPO> uw = new UpdateWrapper<>();
        uw.lambda().eq(BookPO::getId, 1L).set(BookPO::getTypeId, 19L);

        Assertions.assertEquals(1, mapper.update(uw));
        Assertions.assertEquals(19L, mapper.selectById(1L).getTypeId());
    }

    @Test
    public void selectById() {
        BookPO book = mapper.selectById(1L);
        Assertions.assertNotNull(book);
        Assertions.assertEquals(Long.valueOf(100L), book.getTypeId());
    }

    @Test
    public void selectByIds() {
        List<BookPO> books = mapper.selectByIds(Arrays.asList(1L, 3L));
        Assertions.assertEquals(2, books.size());
    }

    @SuppressWarnings("deprecation")
    @Test
    public void selectBatchIds() {
        List<BookPO> books = mapper.selectBatchIds(Arrays.asList(1L, 2L));
        Assertions.assertEquals(2, books.size());
    }

    @Test
    public void selectByIdsWithResultHandler() {
        List<BookPO> result = new ArrayList<>();
        mapper.selectByIds(Arrays.asList(1L, 2L), collectingHandler(result));
        Assertions.assertEquals(2, result.size());
    }

    @SuppressWarnings("deprecation")
    @Test
    public void selectBatchIdsWithResultHandler() {
        List<BookPO> result = new ArrayList<>();
        mapper.selectBatchIds(Arrays.asList(1L, 2L), collectingHandler(result));
        Assertions.assertEquals(2, result.size());
    }

    @Test
    public void selectByMap() {
        Map<String, Object> conditions = new HashMap<>();
        conditions.put("book_isbn", "bbb");
        List<BookPO> result = mapper.selectByMap(conditions);
        Assertions.assertEquals(1, result.size());
        Assertions.assertEquals(Long.valueOf(2L), result.get(0).getId());
    }

    @Test
    public void selectByMapWithResultHandler() {
        Map<String, Object> conditions = new HashMap<>();
        conditions.put("status", StatusEnum.PENDING.name());
        List<BookPO> result = new ArrayList<>();
        mapper.selectByMap(conditions, collectingHandler(result));
        Assertions.assertEquals(3, result.size());
    }

    @Test
    public void selectOne() {
        QueryWrapper<BookPO> qw = new QueryWrapper<>();
        qw.lambda().eq(BookPO::getId, 2L);
        Assertions.assertEquals(Long.valueOf(2L), mapper.selectOne(qw).getId());
    }

    @Test
    public void selectOneWithoutThrowEx() {
        QueryWrapper<BookPO> qw = new QueryWrapper<>();
        qw.lambda().eq(BookPO::getStatus, StatusEnum.PENDING);
        BookPO one = mapper.selectOne(qw, false);
        Assertions.assertNotNull(one);
    }

    @Test
    public void exists() {
        QueryWrapper<BookPO> qw = new QueryWrapper<>();
        qw.lambda().eq(BookPO::getBookIsbn, "ccc");
        Assertions.assertTrue(mapper.exists(qw));
    }

    @Test
    public void selectCount() {
        QueryWrapper<BookPO> qw = new QueryWrapper<>();
        qw.lambda().eq(BookPO::getStatus, StatusEnum.PENDING);
        Assertions.assertEquals(Long.valueOf(3L), mapper.selectCount(qw));
    }

    @Test
    public void selectList() {
        Assertions.assertEquals(3, mapper.selectList(null).size());
    }

    @Test
    public void selectListWithResultHandler() {
        List<BookPO> result = new ArrayList<>();
        mapper.selectList(null, collectingHandler(result));
        Assertions.assertEquals(3, result.size());
    }

    @Test
    public void selectListWithPageParameter() {
        Page<BookPO> page = new Page<>(1, 2);
        List<BookPO> result = mapper.selectList(page, null);
        Assertions.assertFalse(result.isEmpty());
    }

    @Test
    public void selectListWithPageAndResultHandler() {
        Page<BookPO> page = new Page<>(1, 2);
        List<BookPO> result = new ArrayList<>();
        mapper.selectList(page, null, collectingHandler(result));
        Assertions.assertFalse(result.isEmpty());
    }

    @Test
    public void selectMaps() {
        QueryWrapper<BookPO> qw = new QueryWrapper<>();
        qw.lambda().eq(BookPO::getId, 1L);
        List<Map<String, Object>> maps = mapper.selectMaps(qw);
        Assertions.assertEquals(1, maps.size());
        Assertions.assertFalse(maps.get(0).isEmpty());
    }

    @Test
    public void selectMapsWithResultHandler() {
        List<Map<String, Object>> result = new ArrayList<>();
        mapper.selectMaps(null, collectingHandler(result));
        Assertions.assertEquals(3, result.size());
    }

    @Test
    public void selectMapsWithPageParameter() {
        Page<Map<String, Object>> page = new Page<>(1, 2);
        List<Map<String, Object>> result = mapper.selectMaps(page, null);
        Assertions.assertFalse(result.isEmpty());
    }

    @Test
    public void selectMapsWithPageAndResultHandler() {
        Page<Map<String, Object>> page = new Page<>(1, 2);
        List<Map<String, Object>> result = new ArrayList<>();
        mapper.selectMaps(page, null, collectingHandler(result));
        Assertions.assertFalse(result.isEmpty());
    }

    @Test
    public void selectObjs() {
        QueryWrapper<BookPO> qw = new QueryWrapper<>();
        qw.select("id").orderByAsc("id");

        List<Number> ids = mapper.selectObjs(qw);

        List<Long> actual = ids.stream()
                .map(Number::longValue)
                .collect(Collectors.toList());

        Assertions.assertEquals(
                Arrays.asList(1L, 2L, 3L),
                actual
        );
    }

    @Test
    public void selectObjsWithResultHandler() {
        QueryWrapper<BookPO> qw = new QueryWrapper<>();
        qw.select("id").orderByAsc("id");

        List<Number> result = new ArrayList<>();
        mapper.selectObjs(qw, collectingHandler(result));

        List<Long> actual = result.stream()
                .map(Number::longValue)
                .collect(Collectors.toList());

        Assertions.assertEquals(
                Arrays.asList(1L, 2L, 3L),
                actual
        );
    }

    @Test
    public void selectPage() {
        Page<BookPO> page = new Page<>(1, 2);
        Page<BookPO> result = mapper.selectPage(page, null);
        Assertions.assertSame(page, result);
        Assertions.assertFalse(result.getRecords().isEmpty());
    }

    @Test
    public void selectMapsPage() {
        Page<Map<String, Object>> page = new Page<>(1, 2);
        Page<Map<String, Object>> result = mapper.selectMapsPage(page, null);
        Assertions.assertSame(page, result);
        Assertions.assertFalse(result.getRecords().isEmpty());
    }

    private static <T> ResultHandler<T> collectingHandler(final List<T> target) {
        return new ResultHandler<T>() {
            @Override
            public void handleResult(ResultContext<? extends T> resultContext) {
                target.add(resultContext.getResultObject());
            }
        };
    }
}
