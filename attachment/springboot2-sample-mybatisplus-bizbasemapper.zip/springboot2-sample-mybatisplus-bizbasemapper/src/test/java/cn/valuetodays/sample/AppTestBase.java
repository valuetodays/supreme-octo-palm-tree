package cn.valuetodays.sample;

import org.springframework.boot.test.context.SpringBootTest;

/**
 * .
 *
 * @author valuetodays
 * @since 2026-09-01
 */
@SpringBootTest(classes = App.class)
public abstract class AppTestBase {
}
