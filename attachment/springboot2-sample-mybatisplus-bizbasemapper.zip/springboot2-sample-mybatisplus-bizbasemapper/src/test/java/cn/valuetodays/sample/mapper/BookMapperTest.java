package cn.valuetodays.sample.mapper;

import java.util.List;

import cn.valuetodays.sample.AppTestBase;
import cn.valuetodays.sample.entity.po.BookPO;
import cn.valuetodays.sample.entity.po.StatusEnum;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.transaction.annotation.Transactional;

/**
 * Tests for {@link BookMapper}.
 *
 * @author valuetodays
 * @since 2026-09-01
 */
@ActiveProfiles("test")
@Transactional
public class BookMapperTest extends AppTestBase {

    @Autowired
    private BookMapper mapper;
    @Test
    public void selectList() {
        List<BookPO> list = mapper.selectList(null);
        Assertions.assertFalse(list.isEmpty());
    }

    @Test
    public void insert() {
        BookPO po = new BookPO();
        po.setTypeId(999L);
        po.setBookIsbn("test");
        po.setBookName("test-book");
        po.setStatus(StatusEnum.PUBLISHED);

        int rows = mapper.insert(po);

        Assertions.assertEquals(1, rows);
    }

}
