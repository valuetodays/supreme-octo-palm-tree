# springboot-sample-h2-mybatisplus

一个基于 **Spring Boot 2.7.7 + MyBatis-Plus 3.5.15 + H2** 的简单示例工程，用于验证自定义 `BizBaseMapper` 的可行性。

## 背景

MyBatis-Plus 的 `BaseMapper` 提供了非常方便的通用 CRUD 能力，但在业务系统中，`insert(T)` 和 `updateById(T)` 的业务语义较弱。

特别是 `updateById(T)`：不同业务修改最终都汇聚到同一个通用方法，调用处不容易直接看出实际更新字段和业务前置条件，也不利于通过 IDE 的调用关系快速定位具体业务更新。

因此，本工程尝试保留 MyBatis-Plus 其他通用能力，同时不让业务 Mapper 直接使用这些通用写方法。

## 实现方案

工程中同时保留两套 Mapper：

- `BookMapper`：继承 MyBatis-Plus 官方 `BaseMapper`，作为对照组。
- `BookBizMapper`：继承项目自定义 `BizBaseMapper`。

`BizBaseMapper` 基于当前 `BaseMapper` 源码裁剪，不继承 `BaseMapper`，而是直接继承 `Mapper<T>`，并移除 `insert`、`updateById`、`insertOrUpdate` 及相关批量方法。

同时提供 `BizSqlInjector`，继承 `DefaultSqlInjector`：

- 普通 `BaseMapper` 继续使用 MyBatis-Plus 默认 SQL 注入能力；
- 对 `BizBaseMapper` 体系过滤 `Insert` 和 `UpdateById` SQL 注入。

这样既不需要修改或 fork MyBatis-Plus，也可以让新业务 Mapper 在编译期不再暴露这些方法。

业务新增、修改操作应在具体 Mapper 中定义具有明确业务含义的方法，例如：

```java
int createBook(...);

int publishBook(...);
```

## 测试

测试使用 H2 内存数据库，初始化脚本位于 `src/test/resources/db/`。

- `BookMapperTest`：验证官方 `BaseMapper` 的 `selectList` 和 `insert` 仍可正常使用。
- `BookBizMapperAllMethodsTest`：逐项验证 `BizBaseMapper` 保留的方法，并验证 `insert`、`updateById`、`insertOrUpdate` 不会暴露。

该工程主要用于验证实现方案。更完整的设计背景、问题分析和取舍会放在后续的探索文档中。
