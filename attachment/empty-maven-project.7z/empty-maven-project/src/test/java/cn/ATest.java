package cn;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

/**
 * .
 *
 * @author lei.liu
 * @since 2023-07-07
 */
class ATest {

    @Test
    public void test() {
        A a = new A();
        Assertions.assertNotNull(a);
        Assertions.assertEquals(a.getClass(), A.class);
    }

}