package com.example.demo;

import java.util.concurrent.Executor;
import java.util.concurrent.Executors;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

import io.micrometer.core.instrument.MeterRegistry;
import io.micrometer.core.instrument.binder.jvm.ExecutorServiceMetrics;
import org.springframework.aop.interceptor.AsyncUncaughtExceptionHandler;
import org.springframework.scheduling.annotation.AsyncConfigurer;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;
import org.springframework.stereotype.Component;

/**
 * 异步任务线程池装配类
 *
 * @author https://juejin.im/entry/5abb8f6951882555677e9da2
 */
//@Component
public class AsyncTaskExecutePool implements AsyncConfigurer {
    private final MeterRegistry meterRegistry;

    public AsyncTaskExecutePool(MeterRegistry meterRegistry) {
        this.meterRegistry = meterRegistry;
    }

    @Override
    public Executor getAsyncExecutor() {
        ThreadPoolTaskExecutor executor = new ThreadPoolTaskExecutor();
        executor.setCorePoolSize(2);
        executor.setMaxPoolSize(4);
        executor.setQueueCapacity(100);
        executor.setKeepAliveSeconds(60);
        executor.setThreadNamePrefix("xxx-async-pool-wrong-");
        executor.setRejectedExecutionHandler(new ThreadPoolExecutor.CallerRunsPolicy());
        executor.initialize();

        Executors.newSingleThreadScheduledExecutor().schedule(() -> {
            ExecutorServiceMetrics.monitor(
                    meterRegistry,
                    executor.getThreadPoolExecutor(),
                    "xxx-async-poll-executor-wrong"
            );
        }, 1, TimeUnit.SECONDS);

        return executor;
    }

    @Override
    public AsyncUncaughtExceptionHandler getAsyncUncaughtExceptionHandler() {
        return (throwable, method, objects) -> {
            throwable.printStackTrace();
            System.out.println("====" + throwable.getMessage() + "====");
        };
    }
}
