package com.example.demo;

import java.util.concurrent.ThreadPoolExecutor;

import io.micrometer.core.instrument.MeterRegistry;
import io.micrometer.core.instrument.binder.jvm.ExecutorServiceMetrics;
import org.springframework.aop.interceptor.AsyncExecutionAspectSupport;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.autoconfigure.task.TaskExecutionAutoConfiguration;
import org.springframework.boot.context.event.ApplicationReadyEvent;
import org.springframework.context.ApplicationListener;
import org.springframework.context.annotation.Bean;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;

//@Configuration
public class AsyncConfig {

    /**
     * 不要修改本bean的名称.
     * 没有本bean，就会执行org.springframework.boot.autoconfigure.task.TaskExecutionAutoConfiguration#applicationTaskExecutor(org.springframework.boot.task.TaskExecutorBuilder)
     *
     * @see TaskExecutionAutoConfiguration
     * @see AsyncExecutionAspectSupport#DEFAULT_TASK_EXECUTOR_BEAN_NAME
     */
    @Bean(AsyncExecutionAspectSupport.DEFAULT_TASK_EXECUTOR_BEAN_NAME)
    public ThreadPoolTaskExecutor taskExecutor() {
        ThreadPoolTaskExecutor executor = new ThreadPoolTaskExecutor();
        //核心线程池大小
        executor.setCorePoolSize(2);
        //最大线程数
        executor.setMaxPoolSize(5);
        //队列容量
        executor.setQueueCapacity(100);
        //活跃时间
        executor.setKeepAliveSeconds(60);
        //线程名字前缀
        executor.setThreadNamePrefix("xxx-async-pool-");
        executor.setRejectedExecutionHandler(new ThreadPoolExecutor.CallerRunsPolicy());
        executor.initialize();

        return executor;
    }

    // 使用监听器绑定监控，确保此时 MeterRegistry 已经是“完整体”
    @Bean
    public ApplicationListener<ApplicationReadyEvent> metricsBinderTaskExecutor(
            MeterRegistry registry,
            @Qualifier(AsyncExecutionAspectSupport.DEFAULT_TASK_EXECUTOR_BEAN_NAME) ThreadPoolTaskExecutor executor) {
        return event -> {
            if (executor instanceof ThreadPoolTaskExecutor) {
                ExecutorServiceMetrics.monitor(registry,
                        ((ThreadPoolTaskExecutor)executor).getThreadPoolExecutor(),
                        "xxxx-async-executor");
            }
        };
    }
}
