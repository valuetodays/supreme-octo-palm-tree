package cn.xiaoliulab.sample.common.po;

/**
 * .
 *
 * @author valuetodays
 * @since 2026-09-01
 */
public enum StatusEnum {
    PENDING,
    PUBLISHED,
}
