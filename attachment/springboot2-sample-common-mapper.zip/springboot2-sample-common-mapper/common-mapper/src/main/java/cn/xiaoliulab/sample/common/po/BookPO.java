package cn.xiaoliulab.sample.common.po;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;

import java.io.Serializable;

/**
 * .
 *
 * @author valuetodays
 * @since 2026-09-01
 */
@Data
@TableName(value = "t_book", autoResultMap = true)
public class BookPO implements Serializable {
    private static final long serialVersionUID = 1L;
    @TableId(value = "id", type = IdType.AUTO)
    private Long id;
    private Long typeId;
    private String bookIsbn;
    private String bookName;
    private StatusEnum status;

}
