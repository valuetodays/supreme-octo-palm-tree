package cn.xiaoliulab.sample.common.mapper;

import cn.xiaoliulab.sample.common.po.BookPO;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface BookMapper extends BaseMapper<BookPO> {
}
