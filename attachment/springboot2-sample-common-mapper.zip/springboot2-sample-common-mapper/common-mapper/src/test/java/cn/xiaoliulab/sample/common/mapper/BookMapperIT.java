package cn.xiaoliulab.sample.common.mapper;

import java.util.List;

import cn.xiaoliulab.sample.common.po.BookPO;
import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.mybatis.spring.annotation.MapperScan;
import org.springframework.beans.factory.annotation.Autowired;

@Slf4j
@MapperScan(basePackages = {"cn.xiaoliulab.sample.common.mapper"})
public class BookMapperIT extends MapperTestBase {

    @Autowired
    private BookMapper mapper;

    @Test
    public void selectList() {
        List<BookPO> list = mapper.selectList(null);
        Assertions.assertFalse(list.isEmpty());
        log.info("list={}", list);
    }

}
