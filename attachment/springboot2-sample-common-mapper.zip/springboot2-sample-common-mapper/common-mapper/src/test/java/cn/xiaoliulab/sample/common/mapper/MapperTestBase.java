package cn.xiaoliulab.sample.common.mapper;

import com.baomidou.mybatisplus.autoconfigure.MybatisPlusAutoConfiguration;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.boot.autoconfigure.jdbc.DataSourceAutoConfiguration;
import org.springframework.boot.test.context.ConfigFileApplicationContextInitializer;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit.jupiter.SpringExtension;

@ExtendWith(SpringExtension.class)
@ContextConfiguration(
        initializers = ConfigFileApplicationContextInitializer.class
)
@ActiveProfiles("dao-test")
@Configuration(proxyBeanMethods = false)
@Import({
        DataSourceAutoConfiguration.class,
        MybatisPlusAutoConfiguration.class
})
public abstract class MapperTestBase {
}
