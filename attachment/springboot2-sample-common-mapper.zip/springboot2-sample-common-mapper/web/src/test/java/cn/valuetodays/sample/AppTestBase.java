package cn.valuetodays.sample;

import cn.xiaoliulab.sample.App;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest(classes = App.class)
public abstract class AppTestBase {
}
