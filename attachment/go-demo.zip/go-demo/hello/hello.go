package main

import (
	"fmt"
	"log"
	"math"
	"math/rand"
	"time"

	"example.com/greetings"
	"rsc.io/quote"
)

func add(x int, y int) int {
	return x + y
}

type Vertex struct {
	X, Y float64
}

func (v Vertex) Abs() float64 {
	return math.Sqrt(v.X*v.X + v.Y*v.Y)
}

func main() {
	v := Vertex{3, 4}
	fmt.Println(v.Abs())

	const World = "世界"
	fmt.Println("Hello", World)
	fmt.Println("add: ", add(42, 13))

	// Set properties of the predefined Logger, including
	// the log entry prefix and a flag to disable printing
	// the time, source file, and line number.
	log.SetPrefix("greetings: ")
	log.SetFlags(0)

	fmt.Println("Hello, World!")
	fmt.Println(quote.Go())
	// Get a greeting message and print it.
	message2, err := greetings.Hello("Gladys")
	if err != nil {
		log.Fatal(err)
	}
	fmt.Println(message2)

	message3 := fmt.Sprintf(randomFormat(), "Gladys")
	fmt.Println(message3)

	fmt.Println(showFor(1000))
	fmt.Println(showFor(rand.Intn(200) + 1))

	// A slice of names.
	names := []string{"Gladys", "Samantha", "Darrin"}

	// Request greeting messages for the names.
	messages, err := greetings.Hellos(names)
	if err != nil {
		log.Fatal(err)
	}
	// If no error was returned, print the returned map of
	// messages to the console.
	fmt.Println(messages)

	// Request a greeting message.
	message, err := greetings.Hello("")
	// If an error was returned, print it to the console and
	// exit the program.
	if err != nil {
		fmt.Print(" exit \n")
		log.Fatal(err)
	} else {
		fmt.Print(message)
	}
}

// init sets initial values for variables used in the function.
func init() {
	rand.Seed(time.Now().UnixNano())
}

// randomFormat returns one of a set of greeting messages. The returned
// message is selected at random.
func randomFormat() string {
	// A slice of message formats.
	formats := []string{
		"Hi, %v. Welcome!",
		"Great to see you, %v!",
		"Hail, %v! Well met!",
	}

	// Return a randomly selected message format by specifying
	// a random index for the slice of formats.
	return formats[rand.Intn(len(formats))]
}

func showFor(n int) int {
	sum := 1
	for sum < n {
		sum += sum
	}
	return sum
}
