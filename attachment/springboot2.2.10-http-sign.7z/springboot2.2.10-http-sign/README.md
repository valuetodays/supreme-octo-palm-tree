## docker镜像验签问题-2-复现

[docker镜像验签问题-2-复现 - Powered by MinDoc](https://doc.sisiruyi.fun/docs/doc-id-12/a-sign-question-about-docker-image-2-reproduce)

### 测试步骤

我的测试环境：
系统：rocky 9.5
java：8

先启动sign-server，注意需要以docker方式启动。

再启动sign-client，注意需要以docker方式启动。且有三种dockerfile。以docker方式启动8-jdk-alpine时报错“library initialization failed - unable to allocate file descriptor tabl”
    在CentOS Linux release 7.8.2003 (Core)中可以启动。本地就不测试了。
    
```shell
[root@yo8p ~]# cat /etc/centos-release
CentOS Linux release 7.8.2003 (Core)
[root@yo8p ~]# cat /etc/redhat-release
CentOS Linux release 7.8.2003 (Core)
[root@yo8p ~]# uname -r
3.10.0-1127.19.1.el7.x86_64
[root@yo8p ~]# cat /proc/version
Linux version 3.10.0-1127.19.1.el7.x86_64 (mockbuild@kbuilder.bsys.centos.org) (gcc version 4.8.5 20150623 (Red Hat 4.8.5-39) (GCC) ) #1 SMP Tue Aug 25 17:23:54 UTC 2020

```
