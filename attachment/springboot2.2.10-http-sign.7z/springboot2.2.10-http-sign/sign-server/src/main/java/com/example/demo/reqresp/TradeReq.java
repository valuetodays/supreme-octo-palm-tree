package com.example.demo.reqresp;

import lombok.Data;

import java.io.Serializable;

/**
 * .
 *
 * @author lei.liu
 * @since 2025-11-28
 */
@Data
public class TradeReq implements Serializable {
    private String content;
    private String merchantId;
    private String sign;
}
