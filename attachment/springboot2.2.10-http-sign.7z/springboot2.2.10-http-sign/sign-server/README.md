
docker run --rm -it  -v $PWD:/app  -v ~/.m2:/root/.m2  -w /app 3.6.3-jdk-8 mvn clean package -DskipTests

docker build -t sign-server .


docker run -p 8080:8080 --name sign-server -d sign-server

docker logs -f --tail 111 sign-server

